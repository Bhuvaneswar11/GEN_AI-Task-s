from transformers import pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain.schema.output_parser import StrOutputParser
from prompts.explain_prompt import explain_prompt

generator=pipeline("text2text-generation",model="google/flan-t5-base")
llm=HuggingFacePipeline(pipeline=generator)
explanation_chain=explain_prompt |llm|StrOutputParser()