from transformers import pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain.schema.output_parser import StrOutputParser
from prompts.extract_prompt import extract_prompt

generator=pipeline("text2text-generation",model="google/flan-t5-base")
llm=HuggingFacePipeline(pipeline=generator)
extraction_chain=extract_prompt |llm|StrOutputParser()