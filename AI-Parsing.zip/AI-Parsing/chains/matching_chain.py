from transformers import pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain.schema.output_parser import StrOutputParser
from prompts.match_prompt import match_prompt

generator=pipeline("text2text-generation",model="google/flan-t5-base")
llm=HuggingFacePipeline(pipeline=generator)
matching_chain=match_prompt |llm|StrOutputParser()