from transformers import pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain.schema.output_parser import StrOutputParser
from prompts.score_prompt import score_prompt

generator=pipeline("text2text-generation",model="google/flan-t5-base")
llm=HuggingFacePipeline(pipeline=generator)
scoring_chain=score_prompt |llm|StrOutputParser()