import os 

from dotenv import load_dotenv

load_dotenv()
from chains.extraction_chain import extraction_chain
from chains.matching_chain import matching_chain
from chains.scoring_chain import scoring_chain
from chains.explanation_chain import explanation_chain

import sentence_transformers
import numpy as np

embed_model=sentence_transformers.SentenceTransformer("all-MiniLm-L6-v2")

def compute_similarity(resume,job_desc):
    emb1=embed_model.encode(resume)
    emb2=embed_model.encode(job_desc)
    return float(np.dot(emb1,emb2)/(np.linalg.norm(emb1)*np.linalg.norm(emb2)))

def load_file(path):
    with open(path,"r",encoding="utf-8")as f:
        return f.read()
    
def run_pipeline(resume,job_desc,tag):
    extracted=extraction_chain.invoke(
        {"resume":resume},
        config={"tags":[tag]}
    )
    matched=matching_chain.invoke(
        {"resume_data":extracted,"job_description":job_desc},
        config={"tags":[tag]}
    )
    simialrity=compute_similarity(resume,job_desc)
    score=scoring_chain.invoke(
        {"match_data":matched,"similarity":compute_similarity},
        config={"tags":[tag]}
    )
    return score,explanation

if __name__ == "__main__":
    job_desc=load_file("data/job_description.txt")
    
    resumes={
        "strong":load_file("data/resume_strong.txt"),
        "average":load_file("data/resume_average.txt"),
        "weak":load_file("data/resume_weak.txt")
                           
    }
    for tag,resume in resumes.items():
        print(f"\n== {tag.upper()} CANDIDATE ===")
        score,explanation=run_pipeline(resume,job_desc,tag)
        
        print("Score:",score)
        print("Explanation:",explanation)