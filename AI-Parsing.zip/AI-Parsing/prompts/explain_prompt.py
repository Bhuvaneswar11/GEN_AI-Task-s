from langchain.prompts import PromptTemplate
explain_prompt=PromptTemplate(
    input_variables=["score", "match_data"],
    template="""
    Explain the candidate score.
    
    Include:
    - Strengths
    - Weaknesses
    - Final reasoning
    
    Score:{score}
    
    Match Data:
    {match_data}
    
    """
    
)