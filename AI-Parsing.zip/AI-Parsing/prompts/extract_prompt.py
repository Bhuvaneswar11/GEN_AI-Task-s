from langchain.prompts import PromptTemplate
extract_prompt=PromptTemplate(
    input_variables=["resume"],
    template="""
    You are an AI resume parser.
    
    Extract ONLY from the resume:
    - Skills
    - Tools
    - Experience (years)
    
    Rules:
    - Do not assume anything
    - Only extract explicity mentioned info
    - Return JSON format
    
    Resume:
    {resume}
    """
    
)