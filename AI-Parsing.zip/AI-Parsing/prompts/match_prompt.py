from langchain.prompts import PromptTemplate
match_prompt=PromptTemplate(
    input_variables=["resume_data","job_description"],
    template="""
    Compare resume with job description.
    
    Return:
    - Matched Skills
    - Missing Tools
    - Summary
    

    
    Resume:
    {resume_data}
    
    Job Description:
    {job_description}
    """
    
)