from langchain.prompts import PromptTemplate
score_prompt=PromptTemplate(
    input_variables=["match_data","similarity"],
    template="""
    Based on match and similarity score, assign a score (0-100).
    
    Similarity:{similarity}
    
    Match Data:
    {match_data}
    
    Return:
    Score: number only
    """
    
)